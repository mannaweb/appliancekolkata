<?php include 'header.php';?>
 <div class="kc_clfw"></div><section class="kc-elm kc-css-808325 kc_row"><div class="kc-row-container  kc-container"><div class="kc-wrap-columns"><div class="kc-elm kc-css-351930 kc_col-sm-12 kc_column kc_col-sm-12"><div class="kc-col-container">
	<!--Main Slider-->
	<section class="rev_slider_wrapper">
		
			<!-- START Home Slider REVOLUTION SLIDER 6.1.3 --><p class="rs-p-wp-fix"></p>
			<rs-module-wrap id="rev_slider_2_1_wrapper" data-source="gallery" style="background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
				<rs-module id="rev_slider_2_1" style="display:none;" data-version="6.1.3">
					<rs-slides>
						<rs-slide data-key="rs-7" data-title="Slide" data-thumb="assets/uploads/2019/09/banner-1.jpg" data-anim="ei:d;eo:d;s:1000;r:0;t:fade;sl:0;">
							<img src="assets/uploads/2019/09/banner-1.jpg" title="banner-1" width="1920" height="750" class="rev-slidebg" data-no-retina>
<!--
							--><rs-layer
								id="slider-2-slide-7-layer-0" 
								data-type="text"
								data-color="#fccc00"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:-130px,-120px,-120px,-90px;"
								data-text="w:normal;s:30,30,22,16;l:40,40,30,30;fw:700;a:center;"
								data-frame_0="y:100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="sp:1500;"
								data-frame_1_mask="u:t;"
								data-frame_999="y:100%;o:0;st:w;sp:1200;sR:5500;"
								data-frame_999_mask="u:t;"
								style="z-index:5;font-family:Nunito;"
							>Keeping you Cool 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-7-layer-1" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:-60px,-60px,-60px,-40px;"
								data-text="w:normal;s:48,40,30,22;l:100,60,45,40;fw:700;a:center;"
								data-ford="frame_0;frame_1;frame_2;frame_999;"
								data-frame_0="x:-175%;o:1;"
								data-frame_0_mask="u:t;x:100%;"
								data-frame_1="e:Power3.easeOut;sp:1000;"
								data-frame_1_mask="u:t;"
								data-frame_999="sX:0.7;sY:0.7;o:0;e:Back.easeIn;st:w;sp:500;sR:4000;"
								data-frame_2="oX:50%;oY:50%;oZ:0;tp:600px;st:1000;sp:2000;"
								style="z-index:6;font-family:Ubuntu;"
							>Quality Service at Affordable Prices 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-7-layer-2" 
								data-type="shape"
								data-rsp_ch="on"
								data-xy="x:c;y:m;"
								data-text="w:normal;s:20,15,11,6;l:0,19,14,8;"
								data-dim="w:700px,534px,405px,249px;h:2px,1px,1px,1px;"
								data-frame_999="o:0;st:w;sR:6700;"
								style="z-index:7;background-color:rgba(255,255,255,0.2);font-family:Roboto;"
							> 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-7-layer-3" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:60px,60px,60px,50px;"
								data-text="w:normal;s:18,18,16,16;l:26,30,30,26;a:center;"
								data-dim="w:445px;"
								data-frame_0="y:-100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="sp:2500;"
								data-frame_1_mask="u:t;"
								data-frame_999="o:0;st:w;sR:4500;"
								style="z-index:8;font-family:Nunito;"
							>Cooltek provides a wide variety of HVAC services to the homes and businesses since 1965. 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-7-layer-5" 
								class="rev-btn"
								data-type="button"
								data-color="#1e2452"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:150px,160px,150px,125px;"
								data-text="w:normal;s:16,16,14,14;l:46;fw:700;a:center;"
								data-dim="w:180px;minh:0px,none,none,none;"
								data-padding="r:40,31,24,15;l:40,31,24,15;"
								data-border="bor:3px,3px,3px,3px;"
								data-frame_0="x:-175%;o:1;"
								data-frame_0_mask="u:t;x:100%;"
								data-frame_1="e:Power3.easeOut;sp:3500;"
								data-frame_1_mask="u:t;"
								data-frame_999="o:0;st:w;sR:3500;"
								data-frame_hover="c:#4644b6;bgc:#fccc00;bor:3px,3px,3px,3px;sp:100;e:Power1.easeInOut;bri:120%;"
								style="z-index:9;background-color:#fccc00;font-family:Ubuntu;"
							>Read More 
							</rs-layer><!--
-->						</rs-slide>
						<rs-slide data-key="rs-9" data-title="Slide" data-thumb="assets/uploads/2019/09/banner-2.jpg" data-anim="ei:d;eo:d;s:1000;r:0;t:fade;sl:0;">
							<img src="assets/uploads/2019/09/banner-2.jpg" title="banner-2" width="1920" height="750" class="rev-slidebg" data-no-retina>
<!--
							--><rs-layer
								id="slider-2-slide-9-layer-0" 
								data-type="text"
								data-color="#fccc00"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:-120px,-120px,-120px,-90px;"
								data-text="w:normal;s:30,30,22,16;l:40,40,30,30;fw:700;a:center;"
								data-frame_0="sX:0.9;sY:0.9;"
								data-frame_1="sp:1500;"
								data-frame_999="y:100%;o:0;st:w;sp:1200;"
								data-frame_999_mask="u:t;"
								style="z-index:5;font-family:Nunito;"
							>24-Hour Emergency Service. 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-9-layer-1" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:-50px,-60px,-60px,-40px;"
								data-text="w:normal;s:48,40,30,22;l:100,60,45,40;fw:700;a:center;"
								data-frame_0="x:-100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="sp:2000;"
								data-frame_1_mask="u:t;"
								data-frame_999="sX:0.7;sY:0.7;o:0;e:Back.easeIn;st:w;sp:500;"
								style="z-index:6;font-family:Ubuntu;"
							>We Put The Soul in Climate Control 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-9-layer-2" 
								data-type="shape"
								data-rsp_ch="on"
								data-xy="x:c;y:m;"
								data-text="w:normal;s:20,15,11,6;l:0,19,14,8;"
								data-dim="w:700px,534px,405px,249px;h:2px,1px,1px,1px;"
								data-frame_999="o:0;st:w;"
								style="z-index:7;background-color:rgba(255,255,255,0.2);font-family:Roboto;"
							> 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-9-layer-3" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:60px,60px,60px,50px;"
								data-text="w:normal;s:18,18,16,16;l:26,30,30,26;a:center;"
								data-dim="w:445px;"
								data-frame_0="y:100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="sp:2500;"
								data-frame_1_mask="u:t;"
								data-frame_999="o:0;st:w;"
								style="z-index:8;font-family:Nunito;"
							>Cooltek provides a wide variety of HVAC services to the homes and businesses since 1965. 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-9-layer-5" 
								class="rev-btn"
								data-type="button"
								data-color="#1e2452"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:150px,160px,150px,125px;"
								data-text="w:normal;s:16,16,14,14;l:46;fw:700;a:center;"
								data-dim="w:180px;minh:0px,none,none,none;"
								data-padding="r:40,31,24,15;l:40,31,24,15;"
								data-border="bor:3px,3px,3px,3px;"
								data-frame_0="sX:2;sY:2;"
								data-frame_0_mask="u:t;"
								data-frame_1="e:Power4.easeInOut;sp:3000;"
								data-frame_1_mask="u:t;"
								data-frame_999="o:0;st:w;"
								data-frame_hover="c:#4644b6;bgc:#fccc00;bor:3px,3px,3px,3px;sp:100;e:Power1.easeInOut;bri:120%;"
								style="z-index:9;background-color:#fccc00;font-family:Ubuntu;"
							>Read More 
							</rs-layer><!--
-->						</rs-slide>
						<rs-slide data-key="rs-11" data-title="Slide" data-thumb="assets/uploads/2019/09/banner-3.jpg" data-anim="ei:d;eo:d;s:1000;r:0;t:fade;sl:0;">
							<img src="assets/uploads/2019/09/banner-3.jpg" title="banner-3" width="1920" height="750" class="rev-slidebg" data-no-retina>
<!--
							--><rs-layer
								id="slider-2-slide-11-layer-0" 
								data-type="text"
								data-color="#fccc00"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:-120px,-120px,-120px,-90px;"
								data-text="w:normal;s:30,30,22,16;l:40,40,30,30;fw:700;a:center;"
								data-frame_0="sX:2;sY:2;"
								data-frame_0_mask="u:t;"
								data-frame_1="e:Power4.easeInOut;sp:1500;"
								data-frame_1_mask="u:t;"
								data-frame_999="y:100%;o:0;st:w;sp:1200;"
								data-frame_999_mask="u:t;"
								style="z-index:5;font-family:Nunito;"
							>Free Service Calls. 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-11-layer-1" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:-50px,-60px,-60px,-40px;"
								data-text="w:normal;s:48,40,30,22;l:100,60,45,40;fw:700;a:center;"
								data-frame_0="x:100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="sp:2000;"
								data-frame_1_mask="u:t;"
								data-frame_999="sX:0.7;sY:0.7;o:0;e:Back.easeIn;st:w;sp:500;"
								style="z-index:6;font-family:Ubuntu;"
							>Our Service is a Breath of Fresh Air 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-11-layer-2" 
								data-type="shape"
								data-rsp_ch="on"
								data-xy="x:c;y:m;"
								data-text="w:normal;s:20,15,11,6;l:0,19,14,8;"
								data-dim="w:700px,534px,405px,249px;h:2px,1px,1px,1px;"
								data-frame_999="o:0;st:w;"
								style="z-index:7;background-color:rgba(255,255,255,0.2);font-family:Roboto;"
							> 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-11-layer-3" 
								data-type="text"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:60px,60px,60px,50px;"
								data-text="w:normal;s:18,18,16,16;l:26,30,30,26;a:center;"
								data-dim="w:445px;"
								data-frame_0="sX:2;sY:2;"
								data-frame_0_mask="u:t;"
								data-frame_1="e:Power2.easeOut;sp:2500;"
								data-frame_1_mask="u:t;"
								data-frame_999="o:0;st:w;"
								style="z-index:8;font-family:Nunito;"
							>Cooltek provides a wide variety of HVAC services to the homes and businesses since 1965. 
							</rs-layer><!--

							--><rs-layer
								id="slider-2-slide-11-layer-5" 
								class="rev-btn"
								data-type="button"
								data-color="#1e2452"
								data-rsp_ch="on"
								data-xy="x:c;y:m;yo:150px,160px,150px,125px;"
								data-text="w:normal;s:16,16,14,14;l:46;fw:700;a:center;"
								data-dim="w:180px;minh:0px,none,none,none;"
								data-padding="r:40,31,24,15;l:40,31,24,15;"
								data-border="bor:3px,3px,3px,3px;"
								data-frame_0="y:100%;"
								data-frame_0_mask="u:t;"
								data-frame_1="sp:3000;"
								data-frame_1_mask="u:t;"
								data-frame_999="o:0;st:w;"
								data-frame_hover="c:#4644b6;bgc:#fccc00;bor:3px,3px,3px,3px;sp:100;e:Power1.easeInOut;bri:120%;"
								style="z-index:9;background-color:#fccc00;font-family:Ubuntu;"
							>Read More 
							</rs-layer><!--
-->						</rs-slide>
					</rs-slides>
					<rs-progress class="rs-bottom" style="visibility: hidden !important;"></rs-progress>
				</rs-module>
				<script type="text/javascript">
					setREVStartSize({c: 'rev_slider_2_1',rl:[1240,1024,778,480],el:[750,768,960,720],gw:[1340,1024,778,480],gh:[750,768,960,720],layout:'fullwidth',mh:"0"});
					var	revapi2,
						tpj;
					jQuery(function() {
						tpj = jQuery;
						if(tpj("#rev_slider_2_1").revolution == undefined){
							revslider_showDoubleJqueryError("#rev_slider_2_1");
						}else{
							revapi2 = tpj("#rev_slider_2_1").show().revolution({
								jsFileLocation:"assets/plugins/revslider/public/assets/js/",
								sliderLayout:"fullwidth",
								duration:"7000ms",
								visibilityLevels:"1240,1024,778,480",
								gridwidth:"1340,1024,778,480",
								gridheight:"750,768,960,720",
								minHeight:"",
								spinner:"spinner0",
								editorheight:"750,768,960,720",
								responsiveLevels:"1240,1024,778,480",
								disableProgressBar:"on",
								navigation: {
									onHoverStop:false,
									arrows: {
										enable:true,
										tmp:"<div class=\"tp-arr-allwrapper\">	<div class=\"tp-arr-imgholder\"></div>	<div class=\"tp-arr-titleholder\">{{title}}</div>	</div>",
										style:"hermes",
										hide_onmobile:true,
										hide_under:778,
										left: {
											h_offset:0
										},
										right: {
											h_offset:0
										}
									},
									bullets: {
										enable:true,
										tmp:"",
										style:"hermes",
										hide_over:"778px"
									}
								},
								fallbacks: {
									allowHTML5AutoPlayOnAndroid:true
								},
							});
						}
						
					});
				</script>
				<script>
					var htmlDivCss = unescape("%23rev_slider_2_1_wrapper%20.hermes.tparrows%20%7B%0A%09cursor%3Apointer%3B%0A%09background%3A%23ffffff%3B%0A%09width%3A50px%3B%0A%09height%3A100px%3B%0A%09position%3Aabsolute%3B%0A%09display%3Ablock%3B%0A%09z-index%3A1000%3B%0A%7D%0A%0A%23rev_slider_2_1_wrapper%20.hermes.tparrows%3Abefore%20%7B%0A%09font-family%3A%20%27revicons%27%3B%0A%09font-size%3A22px%3B%0A%09color%3A%232d72bb%3B%0A%09display%3Ablock%3B%0A%09line-height%3A%20100px%3B%0A%09text-align%3A%20center%3B%0A%20%20%20%20transform%3Atranslatex%280px%29%3B%0A%20%20%20%20-webkit-transform%3Atranslatex%280px%29%3B%0A%20%20%20%20transition%3Aall%200.3s%3B%0A%20%20%20%20-webkit-transition%3Aall%200.3s%3B%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes.tparrows.tp-leftarrow%3Abefore%20%7B%0A%09content%3A%20%27%5Ce824%27%3B%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes.tparrows.tp-rightarrow%3Abefore%20%7B%0A%09content%3A%20%27%5Ce825%27%3B%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes.tparrows.tp-leftarrow%3Ahover%3Abefore%20%7B%0A%20%20%20%20transform%3Atranslatex%28-20px%29%3B%0A%20%20%20%20-webkit-transform%3Atranslatex%28-20px%29%3B%0A%20%20%20%20%20opacity%3A0%3B%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes.tparrows.tp-rightarrow%3Ahover%3Abefore%20%7B%0A%20%20%20%20transform%3Atranslatex%2820px%29%3B%0A%20%20%20%20-webkit-transform%3Atranslatex%2820px%29%3B%0A%20%20%20%20%20opacity%3A0%3B%0A%7D%0A%0A%23rev_slider_2_1_wrapper%20.hermes%20.tp-arr-allwrapper%20%7B%0A%20%20%20%20overflow%3Ahidden%3B%0A%20%20%20%20position%3Aabsolute%3B%0A%09width%3A180px%3B%0A%20%20%20%20height%3A140px%3B%0A%20%20%20%20top%3A0px%3B%0A%20%20%20%20left%3A0px%3B%0A%20%20%20%20visibility%3Ahidden%3B%0A%20%20%20%20%20%20-webkit-transition%3A%20-webkit-transform%200.3s%200.3s%3B%0A%20%20transition%3A%20transform%200.3s%200.3s%3B%0A%20%20-webkit-perspective%3A%201000px%3B%0A%20%20perspective%3A%201000px%3B%0A%20%20%20%20%7D%0A%23rev_slider_2_1_wrapper%20.hermes.tp-rightarrow%20.tp-arr-allwrapper%20%7B%0A%20%20%20right%3A0px%3Bleft%3Aauto%3B%0A%20%20%20%20%20%20%7D%0A%23rev_slider_2_1_wrapper%20.hermes.tparrows%3Ahover%20.tp-arr-allwrapper%20%7B%0A%20%20%20visibility%3Avisible%3B%0A%20%20%20%20%20%20%20%20%20%20%7D%0A%23rev_slider_2_1_wrapper%20.hermes%20.tp-arr-imgholder%20%7B%0A%20%20width%3A180px%3Bposition%3Aabsolute%3B%0A%20%20left%3A0px%3Btop%3A0px%3Bheight%3A100px%3B%0A%20%20transform%3Atranslatex%28-180px%29%3B%0A%20%20-webkit-transform%3Atranslatex%28-180px%29%3B%0A%20%20transition%3Aall%200.3s%3B%0A%20%20transition-delay%3A0.3s%3B%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes.tp-rightarrow%20.tp-arr-imgholder%7B%0A%20%20%20%20transform%3Atranslatex%28180px%29%3B%0A%20%20-webkit-transform%3Atranslatex%28180px%29%3B%0A%20%20%20%20%20%20%7D%0A%20%20%0A%23rev_slider_2_1_wrapper%20.hermes.tparrows%3Ahover%20.tp-arr-imgholder%20%7B%0A%20%20%20transform%3Atranslatex%280px%29%3B%0A%20%20%20-webkit-transform%3Atranslatex%280px%29%3B%20%20%20%20%20%20%20%20%20%20%20%20%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes%20.tp-arr-titleholder%20%7B%0A%20%20top%3A100px%3B%0A%20%20width%3A180px%3B%0A%20%20text-align%3Aleft%3B%20%0A%20%20display%3Ablock%3B%0A%20%20padding%3A0px%2010px%3B%0A%20%20line-height%3A30px%3B%20background%3A%23000%3B%0A%20%20background%3Argba%280%2C0%2C0%2C0.75%29%3B%0A%20%20color%3A%23ffffff%3B%0A%20%20font-weight%3A600%3B%20position%3Aabsolute%3B%0A%20%20font-size%3A12px%3B%0A%20%20white-space%3Anowrap%3B%0A%20%20letter-spacing%3A1px%3B%0A%20%20-webkit-transition%3A%20all%200.3s%3B%0A%20%20transition%3A%20all%200.3s%3B%0A%20%20-webkit-transform%3A%20rotatex%28-90deg%29%3B%0A%20%20transform%3A%20rotatex%28-90deg%29%3B%0A%20%20-webkit-transform-origin%3A%2050%25%200%3B%0A%20%20transform-origin%3A%2050%25%200%3B%0A%20%20box-sizing%3Aborder-box%3B%0A%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes.tparrows%3Ahover%20.tp-arr-titleholder%20%7B%0A%20%20%20%20-webkit-transition-delay%3A%200.6s%3B%0A%20%20transition-delay%3A%200.6s%3B%0A%20%20-webkit-transform%3A%20rotatex%280deg%29%3B%0A%20%20transform%3A%20rotatex%280deg%29%3B%0A%7D%0A%0A%23rev_slider_2_1_wrapper%20.hermes.tp-bullets%20%7B%0A%7D%0A%0A%23rev_slider_2_1_wrapper%20.hermes%20.tp-bullet%20%7B%0A%20%20%20%20overflow%3Ahidden%3B%0A%20%20%20%20border-radius%3A50%25%3B%0A%20%20%20%20width%3A16px%3B%0A%20%20%20%20height%3A16px%3B%0A%20%20%20%20background-color%3A%20rgba%280%2C%200%2C%200%2C%200%29%3B%0A%20%20%20%20box-shadow%3A%20inset%200%200%200%202px%20%23ffffff%3B%0A%20%20%20%20-webkit-transition%3A%20background%200.3s%20ease%3B%0A%20%20%20%20transition%3A%20background%200.3s%20ease%3B%0A%20%20%20%20position%3Aabsolute%3B%0A%7D%0A%0A%23rev_slider_2_1_wrapper%20.hermes%20.tp-bullet%3Ahover%20%7B%0A%09%20%20background-color%3A%20rgba%280%2C0%2C0%2C0.21%29%3B%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes%20.tp-bullet%3Aafter%20%7B%0A%20%20content%3A%20%27%20%27%3B%0A%20%20position%3A%20absolute%3B%0A%20%20bottom%3A%200%3B%0A%20%20height%3A%200%3B%0A%20%20left%3A%200%3B%0A%20%20width%3A%20100%25%3B%0A%20%20background-color%3A%20%23ffffff%3B%0A%20%20box-shadow%3A%200%200%201px%20%23ffffff%3B%0A%20%20-webkit-transition%3A%20height%200.3s%20ease%3B%0A%20%20transition%3A%20height%200.3s%20ease%3B%0A%7D%0A%23rev_slider_2_1_wrapper%20.hermes%20.tp-bullet.selected%3Aafter%20%7B%0A%20%20height%3A100%25%3B%0A%7D%0A%0A");
					var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
					if(htmlDiv) {
						htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
					}else{
						var htmlDiv = document.createElement('div');
						htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
						document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
					}
				</script>
				<script>
					var htmlDivCss = unescape("%0A%0A%0A%0A%0A%0A");
					var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
					if(htmlDiv) {
						htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
					}else{
						var htmlDiv = document.createElement('div');
						htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
						document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
					}
				</script>
			</rs-module-wrap>
			<!-- END REVOLUTION SLIDER -->
	</section>
	<!--End Main Slider-->

</div></div></div></div></section><section class="kc-elm kc-css-869445 kc_row"><div class="kc-row-container  kc-container"><div class="kc-wrap-columns"><div class="kc-elm kc-css-851465 kc_col-sm-12 kc_column kc_col-sm-12"><div class="kc-col-container"><section class="welcome_section">

    <div class="container">

        <div class="row">

            <div class="col-lg-6 col-md-12 col-sm-12">

                <div class="welcome_left">

                    <div class="image_inner">

                        <img   alt="Awesome Image" data-src="assets/uploads/2019/09/welcome_left.png?lossy=1&strip=1&webp=1" class="img-fluid lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/09/welcome_left41d1.png?lossy=1&amp;strip=1&amp;webp=1" class="img-fluid" alt="Awesome Image" /></noscript>

                    </div>

                    <div class="wel_content_left">

                        <h2>Leading HVAC<br> Service Company In NY</h2>

                        <div class="video-holder">

                            <div class="video_holder_inner clearfix">

                                <div class="icon">

                                    <a class="html5lightbox bg" title="Home" href="https://www.youtube.com/watch?v=b9B1nOyzNvI"><span class="flaticon-multimedia flaticon-play-arrow"></span></a>

                                </div>

                                <div class="text ">

                                    <h6>Watch Video &amp;<br> Know How We Work</h6>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="col-lg-6 col-md-12 col-sm-12">

                <div class="welcome_right">

                    <div class="heading">

                        <h6>WELCOME TO COOLTEK</h6>

                        <div class="border_line"></div>

                    </div>

                    <h1 class="sub_heading">Heating &amp; Air Conditioning Repair &amp; Installation Company</h1>

                    <p class="description">Nor again is there anyone who loves or pursues or desires to obtain pain of because it is pain, but because occasionally circumstances.</p>

                    <div class="list_items clearfix">

                        <ul class="first">

                            
                            
                            <li><span class="flaticon-favourites-filled-star-symbol"></span>Warrantees &amp; Gurantees
</li>

                            
                            <li><span class="flaticon-favourites-filled-star-symbol"></span>Exceed Expectation</li>

                            
                        </ul>

                        <ul class="second">

                            
                            
                            <li><span class="flaticon-favourites-filled-star-symbol"></span>Online Schedule
</li>

                            
                            <li><span class="flaticon-favourites-filled-star-symbol"></span>Financing Available</li>

                            
                        </ul>

                    </div>

                    <div class="authour">

                        <img   alt="Awesome Image" data-src="assets/uploads/2019/09/welcome_sign.png?lossy=1&strip=1&webp=1" class="img-fluid lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/09/welcome_sign41d1.png?lossy=1&amp;strip=1&amp;webp=1" class="img-fluid" alt="Awesome Image" /></noscript>

                        <div class="text">

                            <h2>Carrol Loiue</h2>

                            <p>CEO &amp; Founder of Cooltek</p>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>





<!---welcome---></div></div></div></div></section><section class="kc-elm kc-css-158496 kc_row"><div class="kc-row-container"><div class="kc-wrap-columns"><div class="kc-elm kc-css-766082 kc_col-sm-12 kc_column kc_col-sm-12"><div class="kc-col-container">   

<!---Our Services--->
<section class="our_services">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="heading">
                    <h6>Our Services</h6>
                    <div class="border_line"></div>
                </div>
                <h6 class="sub_heading">What We Can Offer You</h6>
                <p class="descrp">We Provide Fast, Reliable Heating and Air Conditioning Services in Kolkata City and It’s Sourrounding Areas.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="owl-carousel owl-theme three_items">
                                        <div class="our_service_inner">
                        <div class="icon">
                            <span class="flaticon-furniture-and-household"></span>
                        </div>
                        <h2>
                            <a href="heating-and-water/index.html">HVAC Design and Installation</a>
                        </h2>
                        <p>To take a trivial example, which of ever undertakes laborious physical at rxercise, except to ...</p>
                        <div class="read_more">
                            <a href="heating-and-water/index.html">Read More</a>
                        </div>
                    </div>
					                    <div class="our_service_inner">
                        <div class="icon">
                            <span class="flaticon-maintenance-1"></span>
                        </div>
                        <h2>
                            <a href="maintenance-repair/index.html">Maintenance and Repair</a>
                        </h2>
                        <p>To take a trivial example, which of ever undertakes laborious physical at rxercise, except to ...</p>
                        <div class="read_more">
                            <a href="maintenance-repair/index.html">Read More</a>
                        </div>
                    </div>
					                    <div class="our_service_inner">
                        <div class="icon">
                            <span class="flaticon-safe"></span>
                        </div>
                        <h2>
                            <a href="energy-efficiency/index.html">Indoor Air Quality Testing</a>
                        </h2>
                        <p>Know how to pursue pleasure rationally encounter consequences that are extremely ever undertakes.</p>
                        <div class="read_more">
                            <a href="energy-efficiency/index.html">Read More</a>
                        </div>
                    </div>
					                </div>
            </div>
        </div>
    </div>
</section>
<!---Our Services--->

</div></div></div></div></section><section class="kc-elm kc-css-102380 kc_row"><div class="kc-row-container  kc-container"><div class="kc-wrap-columns"><div class="kc-elm kc-css-431195 kc_col-sm-12 kc_column kc_col-sm-12"><div class="kc-col-container">   

<!---Work Gallery--->
<section class="work_gallery">
    <div class="container">
        <div class="top_headings">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div class="heading">
                        <h6>Work Gallery</h6>
                        <div class="border_line"></div>
                    </div>
                    <h1 class="sub_heading">Our Featured Works</h1>
                </div>
                <div class="col-lg-5 col-md-12 col-sm-12">
                    <div class="right_content sme">
                        <p>We Have Done More Than 800 Projects In Last 3 Years, With 100% Satisfaction.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12">
                    <div class="right_btn sme text-right">
                        <a href="our-projects/index.html" class="view_all theme-btn">View All</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                
                <div class="our_services_inner">
                    <div class="image">
                        <img width="370" height="270"   alt="" data-srcset="assets/uploads/2019/09/our_services-1.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-1-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w"  data-src="assets/uploads/2019/09/our_services-1.jpg?lossy=1&strip=1&webp=1" data-sizes="(max-width: 370px) 100vw, 370px" class="img-fluid wp-post-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="370" height="270" src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/09/our_services-141d1.jpg?lossy=1&amp;strip=1&amp;webp=1" class="img-fluid wp-post-image" alt="" srcset="assets/uploads/2019/09/our_services-1.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-1-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w" sizes="(max-width: 370px) 100vw, 370px" /></noscript>                    </div>
                    <div class="over_content">
                        <h2>
                            <a href="projects/new-construction/index.html">New Construction</a>
                        </h2>
                                                <p>Our Featured Works</p>		
                    </div>
                    <div class="sub_text">
                        <h6>Case Studies</h6>
                    </div>
                </div>
            </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                
                <div class="our_services_inner">
                    <div class="image">
                        <img width="370" height="270"   alt="" data-srcset="assets/uploads/2019/09/our_services-2.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-2-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w"  data-src="assets/uploads/2019/09/our_services-2.jpg?lossy=1&strip=1&webp=1" data-sizes="(max-width: 370px) 100vw, 370px" class="img-fluid wp-post-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="370" height="270" src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/09/our_services-241d1.jpg?lossy=1&amp;strip=1&amp;webp=1" class="img-fluid wp-post-image" alt="" srcset="assets/uploads/2019/09/our_services-2.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-2-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w" sizes="(max-width: 370px) 100vw, 370px" /></noscript>                    </div>
                    <div class="over_content">
                        <h2>
                            <a href="projects/new-construction-2/index.html">New Construction</a>
                        </h2>
                                                <p>Our Featured Works</p>		
                    </div>
                    <div class="sub_text">
                        <h6>Case Studies</h6>
                    </div>
                </div>
            </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                
                <div class="our_services_inner">
                    <div class="image">
                        <img width="370" height="270"   alt="" data-srcset="assets/uploads/2019/09/our_services-3.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-3-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w"  data-src="assets/uploads/2019/09/our_services-3.jpg?lossy=1&strip=1&webp=1" data-sizes="(max-width: 370px) 100vw, 370px" class="img-fluid wp-post-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="370" height="270" src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/09/our_services-341d1.jpg?lossy=1&amp;strip=1&amp;webp=1" class="img-fluid wp-post-image" alt="" srcset="assets/uploads/2019/09/our_services-3.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-3-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w" sizes="(max-width: 370px) 100vw, 370px" /></noscript>                    </div>
                    <div class="over_content">
                        <h2>
                            <a href="projects/new-construction-3/index.html">New Construction</a>
                        </h2>
                                                <p>Our Featured Works</p>		
                    </div>
                    <div class="sub_text">
                        <h6>Case Studies</h6>
                    </div>
                </div>
            </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                
                <div class="our_services_inner">
                    <div class="image">
                        <img width="370" height="270"   alt="" data-srcset="assets/uploads/2019/09/our_services-4.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-4-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w"  data-src="assets/uploads/2019/09/our_services-4.jpg?lossy=1&strip=1&webp=1" data-sizes="(max-width: 370px) 100vw, 370px" class="img-fluid wp-post-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="370" height="270" src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/09/our_services-441d1.jpg?lossy=1&amp;strip=1&amp;webp=1" class="img-fluid wp-post-image" alt="" srcset="assets/uploads/2019/09/our_services-4.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-4-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w" sizes="(max-width: 370px) 100vw, 370px" /></noscript>                    </div>
                    <div class="over_content">
                        <h2>
                            <a href="projects/new-construction-4/index.html">New Construction</a>
                        </h2>
                                                <p>Our Featured Works</p>		
                    </div>
                    <div class="sub_text">
                        <h6>Case Studies</h6>
                    </div>
                </div>
            </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                
                <div class="our_services_inner">
                    <div class="image">
                        <img width="370" height="270"   alt="" data-srcset="assets/uploads/2019/09/our_services-5.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-5-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w"  data-src="assets/uploads/2019/09/our_services-5.jpg?lossy=1&strip=1&webp=1" data-sizes="(max-width: 370px) 100vw, 370px" class="img-fluid wp-post-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="370" height="270" src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/09/our_services-541d1.jpg?lossy=1&amp;strip=1&amp;webp=1" class="img-fluid wp-post-image" alt="" srcset="assets/uploads/2019/09/our_services-5.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-5-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w" sizes="(max-width: 370px) 100vw, 370px" /></noscript>                    </div>
                    <div class="over_content">
                        <h2>
                            <a href="projects/new-construction-5/index.html">New Construction</a>
                        </h2>
                                                <p>Our Featured Works</p>		
                    </div>
                    <div class="sub_text">
                        <h6>Case Studies</h6>
                    </div>
                </div>
            </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                
                <div class="our_services_inner">
                    <div class="image">
                        <img width="370" height="270"   alt="" data-srcset="assets/uploads/2019/09/our_services-6.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-6-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w"  data-src="assets/uploads/2019/09/our_services-6.jpg?lossy=1&strip=1&webp=1" data-sizes="(max-width: 370px) 100vw, 370px" class="img-fluid wp-post-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="370" height="270" src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/09/our_services-641d1.jpg?lossy=1&amp;strip=1&amp;webp=1" class="img-fluid wp-post-image" alt="" srcset="assets/uploads/2019/09/our_services-6.jpg?lossy=1&amp;strip=1&amp;webp=1 370w, assets/uploads/2019/09/our_services-6-300x219.jpg?lossy=1&amp;strip=1&amp;webp=1 300w" sizes="(max-width: 370px) 100vw, 370px" /></noscript>                    </div>
                    <div class="over_content">
                        <h2>
                            <a href="projects/new-construction-6/index.html">New Construction</a>
                        </h2>
                                                <p>Our Featured Works</p>		
                    </div>
                    <div class="sub_text">
                        <h6>Case Studies</h6>
                    </div>
                </div>
            </div>
                    </div>
    </div>
</section>
<!---Work Gallery--->

</div></div></div></div></section><section class="kc-elm kc-css-682193 kc_row"><div class="kc-row-container"><div class="kc-wrap-columns"><div class="kc-elm kc-css-872701 kc_col-sm-12 kc_column kc_col-sm-12"><div class="kc-col-container"><!---facts--->
<section class="facts" style="background-image:url(assets/uploads/2019/09/counter_bg41d1.jpg?lossy=1&amp;strip=1&amp;webp=1);">
    <div class="container">
        <div id="counter">
            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="facts_inner">
                        <div class="facts_num">
                            <h6 class="counter-value" data-count="2387">0</h6>
                            <div class="line_bro"></div>
                        </div>
                        <div class="text_inner">
                            <h2>CUSTOMERS</h2>
                            <p> 100% Satisfied With Our Work</p>
                        </div>
                    </div>
                </div>
                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="facts_inner">
                        <div class="facts_num">
                            <h6 class="counter-value" data-count="124">0</h6>
                            <div class="line_bro"></div>
                        </div>
                        <div class="text_inner">
                            <h2>PROFESSIONAL</h2>
                            <p> Engineers Working In Our Company</p>
                        </div>
                    </div>
                </div>
                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="facts_inner">
                        <div class="facts_num">
                            <h6 class="counter-value" data-count="6">0</h6>
                            <div class="line_bro"></div>
                        </div>
                        <div class="text_inner">
                            <h2>BRANCHES</h2>
                            <p> Operating In NY &amp; It’s Sorrounding</p>
                        </div>
                    </div>
                </div>
                            </div>
        </div>
    </div>
</section>
<!---facts---></div></div></div></div></section><section class="kc-elm kc-css-343235 kc_row"><div class="kc-row-container"><div class="kc-wrap-columns"><div class="kc-elm kc-css-215203 kc_col-sm-12 kc_column kc_col-sm-12"><div class="kc-col-container"> 
   

<!---testimonial_inner--->
<section class="testimonial_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 padding_right_zero">
                <div class="testimonial_outer">
                    <div class="testimonial_inner">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="heading">
                                    <h6>Testimonials</h6>
                                    <div class="border_line"></div>
                                </div>
                                <h6 class="sub_heading">Words From Customers</h6>

                            </div>
                        </div>
                        <div class="owl-carousel owl-theme testimonial_carousel">
                                                        <div class="test_inner">
                                <div class="cust_name">
                                    <h2>Osborne Norton</h2>
                                    <h6>Bronx, New York.</h6>
                                </div>
                                <p class="description">Cooltek helped me out when I was in a pinch. Ryan was very personable, knowledgeable, and professional. He was able to solve the problem in an efficient manner.</p>
                                <ul>
                                    <li>
                                    	<span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span>                                	</li>
                                </ul>
                                <p>Rated 4.5 Out Of 140 Reviews</p>
                            </div>
							                            <div class="test_inner">
                                <div class="cust_name">
                                    <h2>Osborne Norton</h2>
                                    <h6>Bronx, New York.</h6>
                                </div>
                                <p class="description">Cooltek helped me out when I was in a pinch. Ryan was very personable, knowledgeable, and professional. He was able to solve the problem in an efficient manner.</p>
                                <ul>
                                    <li>
                                    	<span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span>                                	</li>
                                </ul>
                                <p>Rated 4.5 Out Of 140 Reviews</p>
                            </div>
							                            <div class="test_inner">
                                <div class="cust_name">
                                    <h2>Osborne Norton</h2>
                                    <h6>Bronx, New York.</h6>
                                </div>
                                <p class="description">Cooltek helped me out when I was in a pinch. Ryan was very personable, knowledgeable, and professional. He was able to solve the problem in an efficient manner.</p>
                                <ul>
                                    <li>
                                    	<span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-favourites-filled-star-symbol"></span><span class="flaticon-star-1"></span>                                	</li>
                                </ul>
                                <p>Rated 4.5 Out Of 140 Reviews</p>
                            </div>
							                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 ">
                <div class="schedule_appointment">
                    <div class="appointment_inner">
                        <div class="topic">
                            <h1>Schedule an Appointment</h1>
                        </div>
                        <div class="form_inner">
                            <div role="form" class="wpcf7" id="wpcf7-f444-p449-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="http://commonsupport.net/newwp/cooltek/#wpcf7-f444-p449-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="444" />
<input type="hidden" name="_wpcf7_version" value="5.1.4" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f444-p449-o1" />
<input type="hidden" name="_wpcf7_container_post" value="449" />
</div>
<div class="row">
<div class="col-lg-6">
<div class="form-group">
<span class="wpcf7-form-control-wrap text-245"><input type="text" name="text-245" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Name" /></span>
</div>
</div>
<div class="col-lg-6">
<div class="form-group">
<span class="wpcf7-form-control-wrap email-233"><input type="email" name="email-233" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email" /></span>
</div>
</div>
<div class="col-lg-6">
<div class="form-group">
<span class="wpcf7-form-control-wrap text-246"><input type="text" name="text-246" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Phone No." /></span>
</div>
</div>
<div class="col-lg-6">
<div class="form-group">
<span class="wpcf7-form-control-wrap menu-311"><select name="menu-311" class="wpcf7-form-control wpcf7-select" id="service" aria-invalid="false"><option value="Select Service">Select Service</option><option value="Slow">Slow</option><option value="Medium">Medium</option><option value="Fast">Fast</option><option value="Faster">Faster</option></select></span>
</div>
</div>
<div class="col-lg-6">
<div class="form-group">
<span class="wpcf7-form-control-wrap text-247"><input type="text" name="text-247" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Zip Code" /></span>
</div>
</div>
<div class="col-lg-6">
<div class="form-group">
<span class="wpcf7-form-control-wrap menu-312"><select name="menu-312" class="wpcf7-form-control wpcf7-select" id="customer" aria-invalid="false"><option value="Are You a New Customer">Are You a New Customer</option><option value="Slow">Slow</option><option value="Medium">Medium</option><option value="Fast">Fast</option><option value="Faster">Faster</option></select></span>
</div>
</div>
<div class="col-lg-12">
<div class="form-group">
<span class="wpcf7-form-control-wrap textarea-859"><textarea name="textarea-859" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Write Your Message..."></textarea></span>
</div>
</div>
<div class="col-lg-4 col-md-5 col-sm-12">
<div class="form-group">
<input type="submit" value="Send Message" class="wpcf7-form-control wpcf7-submit theme-btn" />
</div>
</div>
<div class="col-lg-8 col-md-7 col-sm-12">
<p>*Our Customer SupportTeam Will Contact You With In 24 Hrs.
</p>
</div>
</div>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div>                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!---testimonial_inner--->


</div></div></div></div></section>	
	<div class="clearfix"></div>
	
	
<!---news_and_updates--->
<section class="offer_banner">
    <div class="container">
        <div class="offer_banner_outer" style="background-image:url(assets/themes/aircol/images/resources/offer_banner41d1.jpg?lossy=1&amp;strip=1&amp;webp=1);">
            <div class="offer_banner_inner">
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-sm-12">
                        <div class="offer_left">
                            <div class="text_l">
                                <h1>20%</h1>
<span>off</span>                            </div>
                            <div class="text_r">
                                <h2>AC or Heating Maintenance &amp; Repair</h2>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="offer_right">
                            <a href="#" class="theme-btn">Print Your Coupon</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php';?>
