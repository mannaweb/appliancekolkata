	
<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from commonsupport.net/newwp/cooltek/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 20 Feb 2022 13:28:10 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
	<link rel="shortcut icon" href="assets/themes/aircol/images/favicon.html" type="image/x-icon">
	<link rel="icon" href="assets/themes/aircol/images/favicon.html" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

<title>Cooltek &#8211; Cooltek WordPress Theme</title>
<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel='dns-prefetch' href='http://727512.smushcdn.com/' />
<link rel="alternate" type="application/rss+xml" title="Cooltek &raquo; Feed" href="feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Cooltek &raquo; Comments Feed" href="comments/feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/commonsupport.net\/newwp\/cooltek\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.14"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])?!1:!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='assets/css/dist/block-library/style.min4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='assets/css/dist/block-library/theme.min4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='assets/plugins/contact-form-7/includes/css/styles58e0.css?ver=5.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='assets/plugins/revslider/public/assets/css/rs66fb3.css?ver=6.1.3' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='bootstrap-css'  href='assets/themes/aircol/css/bootstrap.min4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-ui-css'  href='assets/themes/aircol/css/jquery-ui.min4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='owl-css'  href='assets/themes/aircol/css/owl4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='lightgallery-css'  href='assets/themes/aircol/css/lightgallery.min4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css'  href='assets/themes/aircol/css/animate4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='assets/themes/aircol/css/font-awesome.min4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='hover-css'  href='assets/themes/aircol/css/hover4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='flaticon-css'  href='assets/themes/aircol/css/flaticon4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='bxslider-css'  href='assets/themes/aircol/css/jquery.bxslider4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-css'  href='assets/themes/aircol/css/owl.carousel4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='owl-theme-css'  href='assets/themes/aircol/css/owl.theme.default.min4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-touchspin-css'  href='assets/themes/aircol/css/jquery.bootstrap-touchspin4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-css'  href='assets/themes/aircol/css/jquery.fancybox4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='prettyPhoto-css'  href='assets/themes/aircol/css/prettyPhoto4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-select-css'  href='assets/themes/aircol/css/bootstrap-select.min4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='imagehover-css'  href='assets/themes/aircol/css/imagehover4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='nouislider-css'  href='assets/themes/aircol/css/nouislider4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='nouislider-pips-css'  href='assets/themes/aircol/css/nouislider.pips4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='flexslider-css'  href='assets/themes/aircol/css/flexslider4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='timePicker-css'  href='assets/themes/aircol/css/timePicker4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='scrollbar-css'  href='assets/themes/aircol/css/scrollbar4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='language-switcher-css'  href='assets/themes/aircol/css/polyglot-language-switcher4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='aircol-style-demo-css'  href='assets/themes/aircol/css/style-new4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='aircol-main-style-css'  href='assets/themes/aircol/style4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='aircol-custom-style-css'  href='assets/themes/aircol/css/custom4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='aircol-responsive-css'  href='assets/themes/aircol/css/responsive4827.css?ver=5.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='aircol-theme-slug-fonts-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700%2C800%7CRaleway%3A300%2C400%2C500%2C600%2C700%2C800%2C900%7CNunito%3A400%2C600%2C700%2C800%7CUbuntu%3A400%2C500%2C700&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='kc-general-css'  href='assets/plugins/kingcomposer/assets/frontend/css/kingcomposer.min4dc3.css?ver=2.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='kc-animate-css'  href='assets/plugins/kingcomposer/assets/css/animate4dc3.css?ver=2.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='kc-icon-1-css'  href='assets/themes/aircol/css/flaticon4dc3.css?ver=2.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='kc-icon-2-css'  href='assets/plugins/kingcomposer/assets/css/icons4dc3.css?ver=2.8.2' type='text/css' media='all' />
<script type='text/javascript' src='assets/js/jquery/jquery4a5f.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='assets/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<script type='text/javascript' src='assets/plugins/revslider/public/assets/js/revolution.tools.minf049.js?ver=6.0'></script>
<script type='text/javascript' src='assets/plugins/revslider/public/assets/js/rs6.min6fb3.js?ver=6.1.3'></script>
<link rel='https://api.w.org/' href='wp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="assets/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.2.14" />
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='index.html' />
<link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embed4d12.json?url=http%3A%2F%2Fcommonsupport.net%2Fnewwp%2Fcooltek%2F" />
<link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embedc9ce.html?url=http%3A%2F%2Fcommonsupport.net%2Fnewwp%2Fcooltek%2F&amp;format=xml" />
<script type="text/javascript">var kc_script_data={ajax_url:"http://commonsupport.net/newwp/cooltek/wp-admin/admin-ajax.php"}</script>		<script>
			document.documentElement.className = document.documentElement.className.replace( 'no-js', 'js' );
		</script>
				<style>
			.no-js img.lazyload { display: none; }
			figure.wp-block-image img.lazyloading { min-width: 150px; }
							.lazyload, .lazyloading { opacity: 0; }
				.lazyloaded {
					opacity: 1;
					transition: opacity 400ms;
					transition-delay: 0ms;
				}
					</style>
				<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<meta name="generator" content="Powered by Slider Revolution 6.1.3 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(t){try{var h,e=document.getElementById(t.c).parentNode.offsetWidth;if(e=0===e||isNaN(e)?window.innerWidth:e,t.tabw=void 0===t.tabw?0:parseInt(t.tabw),t.thumbw=void 0===t.thumbw?0:parseInt(t.thumbw),t.tabh=void 0===t.tabh?0:parseInt(t.tabh),t.thumbh=void 0===t.thumbh?0:parseInt(t.thumbh),t.tabhide=void 0===t.tabhide?0:parseInt(t.tabhide),t.thumbhide=void 0===t.thumbhide?0:parseInt(t.thumbhide),t.mh=void 0===t.mh||""==t.mh||"auto"===t.mh?0:parseInt(t.mh,0),"fullscreen"===t.layout||"fullscreen"===t.l)h=Math.max(t.mh,window.innerHeight);else{for(var i in t.gw=Array.isArray(t.gw)?t.gw:[t.gw],t.rl)void 0!==t.gw[i]&&0!==t.gw[i]||(t.gw[i]=t.gw[i-1]);for(var i in t.gh=void 0===t.el||""===t.el||Array.isArray(t.el)&&0==t.el.length?t.gh:t.el,t.gh=Array.isArray(t.gh)?t.gh:[t.gh],t.rl)void 0!==t.gh[i]&&0!==t.gh[i]||(t.gh[i]=t.gh[i-1]);var r,a=new Array(t.rl.length),n=0;for(var i in t.tabw=t.tabhide>=e?0:t.tabw,t.thumbw=t.thumbhide>=e?0:t.thumbw,t.tabh=t.tabhide>=e?0:t.tabh,t.thumbh=t.thumbhide>=e?0:t.thumbh,t.rl)a[i]=t.rl[i]<window.innerWidth?0:t.rl[i];for(var i in r=a[0],a)r>a[i]&&0<a[i]&&(r=a[i],n=i);var d=e>t.gw[n]+t.tabw+t.thumbw?1:(e-(t.tabw+t.thumbw))/t.gw[n];h=t.gh[n]*d+(t.tabh+t.thumbh)}void 0===window.rs_init_css&&(window.rs_init_css=document.head.appendChild(document.createElement("style"))),document.getElementById(t.c).height=h,window.rs_init_css.innerHTML+="#"+t.c+"_wrapper { height: "+h+"px }"}catch(t){console.log("Failure at Presize of Slider:"+t)}};</script>
<script type="text/javascript"></script><style type="text/css" id="kc-css-general">.kc-off-notice{display: inline-block !important;}.kc-container{max-width:1170px;}</style><style type="text/css" id="kc-css-render"></style></head>

<body class="home page-template page-template-tpl-king_composer page-template-tpl-king_composer-php page page-id-404 kingcomposer kc-css-system">

<div class="page-wrapper">
 	
    		<!-- Preloader -->
		<div class="preloader"></div>
        <div class="header_outer">
    <!--header_outer-->
        <div class="top_bar">
        <!--top_bar-->
        <div class="container">
            <div class="row">

                <div class="col-lg-5 col-md-12 col-sm-12">
                                        <div class="top_widgets first">
                        <span class="flaticon-alarm-clock-1"></span>
                        <p>Its Friday, 3:00pm &amp; We are Open Till 6.00pm</p>
                    </div>
                                    </div>
                <div class="col-lg-7 col-md-12 col-sm-12">
                    <div class="top_widgets left clearfix">
                                                <div class="text_warp">
                            <span class="flaticon-calendar-1"></span>
                            <p>Schedule a Service</p>
                        </div>
                                                
                                                <div class="text_warp">
                            <span class="flaticon-campfire"></span>
                            <p>Request a Quote</p>
                        </div>
                                                
                        <div class="text_warp last">
                            
							                                                                    <ul>
                                                                                    <li><a href="http://facebook.com/"><i class="fa fa-facebook"></i></a></li>
                                                                                    <li><a href="http://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                                                                                    <li><a href="http://instagram.com/"><i class="fa fa-instagram"></i></a></li>
                                                                                    <li><a href="http://pinterest.com/"><i class="fa fa-pinterest"></i></a></li>
                                                                            </ul>
                                                                                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--top_bar-->
    </div>
		<div class="new-header-middle">
        <!--top_bar-->
        <div class="container">
            <div class="clearfix">
    
                <div class="logo-box">
                    <div class="logo">
						                            <a href="index.php"><img   alt="Awesome Image" data-src="assets/uploads/2019/11/logo-2x41d1.png" class="img-fluid lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="><noscript><img src="assets/uploads/2019/11/logo-2x41d1.png" class="img-fluid" alt="Awesome Image"></noscript></a>
                                            </div>
                </div>
                <!--Right Content-->
                <div class="right-content clearfix">
                    <div class="info-boxes clearfix">
                                                <div class="info-box">
                            <span class="flaticon-pin icon"></span>
                            <div class="inner">
                                <h6>Kolkata, INDIA</h6>
                                <p>Flat 201, Reynolds Neck Str</p>
                            </div>
                        </div>
                                                                        <div class="info-box">
                            <span class="flaticon-email icon"></span>
                            <div class="inner">
                                <h6>Mail us on</h6>
                                <p>support@example.com</p>
                            </div>
                        </div>
                               
                                            </div>
                </div>
            </div>
        </div>
        <!--top_bar-->
    </div>
    <div class="new-header-lower">
        <!--top_bar-->
       <?php $uriSegments = explode("/", parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)); 
      // echo '<pre>';print_r($uriSegments);die;
       ?>
        <div class="container">
            <div class="clearfix">
    
                <div class="new-nav-box">
                    <div class="inner">
                        <ul class="new-navigation menu-depend">
                        <li id="menu-item-225" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-225"><a title="Home" href="index.php" class="hvr-underline-from-left1" data-scroll data-options="easing: easeOutQuart">Home</a></li>
                        <li id="menu-item-225" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-225"><a title="About" href="about.php" class="hvr-underline-from-left1" data-scroll data-options="easing: easeOutQuart">About Us</a></li>

<li id="menu-item-182" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-182 dropdown"><a title="Services" href="services/index.html" data-toggle="dropdown1" class="hvr-underline-from-left1" aria-expanded="false" data-scroll data-options="easing: easeOutQuart">Services</a>
<ul role="menu" class="submenu">
	<li id="menu-item-195" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-195"><a title="A/C Installation" href="ac-installation/index.html">A/C Installation</a></li>
	<li id="menu-item-203" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-203"><a title="Maintenance &#038; Repair" href="maintenance-repair/index.html">Maintenance &#038; Repair</a></li>
	<li id="menu-item-209" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-209"><a title="Diagnostics" href="diagnostics/index.html">Diagnostics</a></li>
	<li id="menu-item-213" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-213"><a title="Cleaning &#038; Optimization" href="cleaning-optimization/index.html">Cleaning &#038; Optimization</a></li>
	<li id="menu-item-216" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-216"><a title="Heating And Water" href="heating-and-water/index.html">Heating And Water</a></li>
	<li id="menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-220"><a title="Energy Efficiency" href="energy-efficiency/index.html">Energy Efficiency</a></li>
</ul>
</li>


<li id="menu-item-326" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-326"><a title="Contact Us" href="contact.php" class="hvr-underline-from-left1" data-scroll data-options="easing: easeOutQuart">Contact Us</a></li>
                        </ul>
                    </div>
    
                    <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
                </div>
    
                <!--Lower Info Box-->
                                <div class="lower-info-box">
                    <div class="inner">
                        <div class="emergency-call clearfix">
                            <div class="icon">
                                <a href="tel:http://+%20(901)%20855%20678%2090%20"><span class="flaticon-24-hours-delivery"></span></a>
                            </div>
                            <div class="text">
                                <p>Call for Emergecy</p>
                                <a href="tel:http://+%20(901)%20855%20678%2090%20">+ (901) 855 678 90 </a>
                            </div>
                        </div>
                    </div>
                </div>
                            </div>
        </div>
        <!--top_bar-->
    </div>

    <!--Mobile navbar-->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><span class="icon">×</span></div>
        
        <nav class="menu-box">
            <div class="nav-logo">
            	                    <a href="index.html"><img  alt="Awesome Image" data-src="assets/uploads/2019/11/logo-light.png?lossy=1&strip=1&webp=1" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="><noscript><img src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/11/logo-light41d1.png?lossy=1&amp;strip=1&amp;webp=1" alt="Awesome Image"></noscript></a>
                            </div>
            <div class="menu-outer">
                <ul class="mobile-navigation">
                                    </ul>
            </div>
            <!--Social Links-->
            <div class="social-links">
							                    <ul class="clearfix">
                                                    <li><a href="http://facebook.com/"><span class="fa fa-facebook"></span></a></li>
                                                    <li><a href="http://twitter.com/"><span class="fa fa-twitter"></span></a></li>
                                                    <li><a href="http://instagram.com/"><span class="fa fa-instagram"></span></a></li>
                                                    <li><a href="http://pinterest.com/"><span class="fa fa-pinterest"></span></a></li>
                                            </ul>
                                        </div>
        </nav>
    </div><!-- End Mobile Menu -->
    
    <!--Search Popup-->
    <div id="search">
        <button type="button" class="close">×</button>
        <form method="get" action="http://commonsupport.net/newwp/cooltek/">
    <div class="search">
        <input type="search" name="s" value="" placeholder="Search">
        <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
    </div>
</form>    </div>
    <!--navbar-->
    <!--header_outer-->
    </div>