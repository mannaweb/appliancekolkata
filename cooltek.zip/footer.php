 <!--Start footer area-->  
 <section class="footer p-t180">
                <div class="container">
                    <div class="row">
                      <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"><div id="bunch_about_us-3" class="single-footer-widget footer_widgets footer-widget widget_bunch_about_us">      		
			<!--Footer Column-->
            <div class="mar-btm">
                <div class="footer-logo">
                    <a href="index.html">
                        <img  alt="Awesome Image" data-src="assets/uploads/2019/11/logo-light.png?lossy=1&strip=1&webp=1" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="><noscript><img src="../../../727512.smushcdn.com/1872962/assets/uploads/2019/11/logo-light41d1.png?lossy=1&amp;strip=1&amp;webp=1" alt="Awesome Image"></noscript>
                    </a>
                </div>
                <div class="our-info">
                    <h5>Experienced Care for Your Heat and Air.</h5>
<p>Cooltek has been business in Newyork, US since 1965. During that time, we have taken great care to build a successful HVAC business.</p>                    <div class="button">
                        <a class="" href="contact-us/index.html"><span class="flaticon-arrows-1"></span>Get a Free Quote</a>
                    </div>
                </div>
            </div>
            
		</div></div><div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"><div id="pages-2"  class="single-footer-widget footer_widgets footer-widget widget_pages"><h2 class="title">Useful Information</h2>		<ul>
			<li class="page_item page-item-183"><a href="ac-installation/index.html">A/C Installation</a></li>
<li class="page_item page-item-58"><a href="about-us/index.html">About Us</a></li>
<li class="page_item page-item-324"><a href="contact-us/index.html">Contact Us</a></li>
<li class="page_item page-item-140"><a href="faqs/index.html">FAQs</a></li>
<li class="page_item page-item-404 current_page_item"><a href="index.html" aria-current="page">Home</a></li>
<li class="page_item page-item-524"><a href="home-02/index.html">Home 02</a></li>
<li class="page_item page-item-7"><a href="home-old/index.html">Home-old</a></li>
<li class="page_item page-item-201"><a href="maintenance-repair/index.html">Maintenance &#038; Repair</a></li>
<li class="page_item page-item-108"><a href="meet-our-team/index.html">Meet Our Team</a></li>
<li class="page_item page-item-116"><a href="our-projects/index.html">Our Projects</a></li>
<li class="page_item page-item-222"><a href="reviews/index.html">Reviews</a></li>
<li class="page_item page-item-165"><a href="services/index.html">Services</a></li>
		</ul>
			</div></div><div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"><div id="bunch_subscribe-2" class="single-footer-widget footer_widgets footer-widget widget_bunch_subscribe">      		
        <div class="footer_widgets sub">
            <h2 class="title">Subscribe Today</h2>        
            <p>Subscribe us to get updates, news &amp; tips in your inbox.</p>
            <form method="post" action="http://feedburner.google.com/fb/a/mailverify" accept-charset="utf-8">
                <input type="hidden" id="furi2" name="uri" value="WordPress">
                <input type="email" name="email" placeholder="Email Address...">
                <button class="theme-btn" type="submit"><i class="flaticon-send"></i></button>
        
            </form>
            <p>We do not share your email id</p>
        </div>
        
		</div></div>  
                    </div>
                </div>
            </section> 
          
        <!--End footer area-->
        
	    <!--Start footer bottom area--> 
    
    <section class="footer_last">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <p>Copyrights © 2019 All Rights Reserved by <a href="#">Cooltek.</a></p>
                </div>
                <div class="col-lg-6 col-md-12">
                    <ul>
                        <li id="menu-item-466" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-466"><a title="Terms &amp; Conditions" href="#" class="hvr-underline-from-left1" data-scroll data-options="easing: easeOutQuart">Terms &#038; Conditions</a></li>
<li id="menu-item-467" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-467"><a title="Privacy Policy" href="#" class="hvr-underline-from-left1" data-scroll data-options="easing: easeOutQuart">Privacy Policy</a></li>
<li id="menu-item-468" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-468"><a title="Sitemap" href="#" class="hvr-underline-from-left1" data-scroll data-options="easing: easeOutQuart">Sitemap</a></li>
    				</ul>
                </div>
    
            </div>
        </div>
    </section>
    
    <!--End footer bottom area-->  

        
</div>
<!--End pagewrapper-->    

<link href="https://fonts.googleapis.com/css?family=Nunito:700%2C400%7CUbuntu:700%7CRoboto:400" rel="stylesheet" property="stylesheet" media="all" type="text/css" >

		<script type="text/javascript">
		if(typeof revslider_showDoubleJqueryError === "undefined") {
			function revslider_showDoubleJqueryError(sliderID) {
				var err = "<div class='rs_error_message_box'>";
				err += "<div class='rs_error_message_oops'>Oops...</div>";
				err += "<div class='rs_error_message_content'>";
				err += "You have some jquery.js library include that comes after the Slider Revolution files js inclusion.<br>";
				err += "To fix this, you can:<br>&nbsp;&nbsp;&nbsp; 1. Set 'Module General Options' ->  'jQuery & OutPut Filters' -> 'Put JS to Body' to on";
				err += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jQuery.js inclusion and remove it";
				err += "</div>";
			err += "</div>";
				jQuery(sliderID).show().html(err);
			}
		}
		</script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/commonsupport.net\/newwp\/cooltek\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='assets/plugins/contact-form-7/includes/js/scripts58e0.js?ver=5.1.4'></script>
<script type='text/javascript' src='assets/plugins/wp-smush-pro/app/assets/js/smush-lazy-load.mina767.js?ver=3.6.3'></script>
<script type='text/javascript'>
lazySizes.cfg.nativeLoading={setLoadingAttribute:false,disableListeners:{scroll:true}};lazySizes.init();
</script>
<script type='text/javascript' src='assets/js/jquery/ui/core.mine899.js?ver=1.11.4'></script>
<script type='text/javascript' src='assets/themes/aircol/js/bootstrap.min431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.bxslider.min431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery-ui.min431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.countTo431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/owl431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/owl.carousel.min431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.mixitup.min431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.easing.min431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.fitvids431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/html5lightbox431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.polyglot.language.switcher431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.fancybox.pack431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.appear431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/isotope431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/wow431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/scrollbar4827.js?ver=5.2.14'></script>
<script type='text/javascript' src='assets/themes/aircol/js/jquery.prettyPhoto431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/timePicker431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/bootstrap-select431f.js?ver=2.1.2'></script>
<script type='text/javascript' src='assets/themes/aircol/js/custom4827.js?ver=5.2.14'></script>
<script type='text/javascript'>
if( ajaxurl === undefined ) var ajaxurl = "wp-admin/admin-ajax.html";
</script>
<script type='text/javascript' src='assets/themes/aircol/js/demo4827.js?ver=5.2.14'></script>
<script type='text/javascript' src='assets/themes/aircol/js/map-script4827.js?ver=5.2.14'></script>
<script type='text/javascript' src='assets/js/comment-reply.min4827.js?ver=5.2.14'></script>
<script type='text/javascript' src='assets/plugins/kingcomposer/assets/frontend/js/kingcomposer.min4dc3.js?ver=2.8.2'></script>
<script type='text/javascript' src='assets/js/wp-embed.min4827.js?ver=5.2.14'></script>
</body>

<!-- Mirrored from commonsupport.net/newwp/cooltek/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 20 Feb 2022 13:29:40 GMT -->
</html>