<?php include 'header.php';?>
<!--Start breadcrumb area-->     
<section class="breadcrumb-area">
	<div class="container text-center">
		<h1>A/C Installation</h1>
	</div>
</section>
<!--End breadcrumb area-->

<!--Start breadcrumb bottom area-->
<section class="breadcrumb-botton-area">
    <div class="container">
        <div class="left">
            <ul class=""><li><a href="../index.html">Home</a></li><li>A/C Installation</li></ul>    
        </div>
    </div>
</section>
<!--End breadcrumb bottom area-->

<div class="kc_clfw"></div><section id="service-single-area" class="kc-elm kc-css-97580 kc_row smartphone-repair-area"><div class="kc-row-container  kc-container"><div class="kc-wrap-columns"><div class="kc-elm kc-css-421840 kc_col-sm-3 kc_column kc_col-sm-3"><div class="service-single-sidebar kc-col-container"><div class="kc-elm kc-css-83294 widget-area kc-wp-sidebar"><div id="bunch_servies-3" class="side-bar widget sidebar_widget widget_bunch_servies">		
        <!--Start single sidebar-->
        <div class="single-sidebar">
            <ul class="service-lists">
                        
           	<!-- Title -->
                        <li><a href="../services/indoor-air-quality-testing/index.html">Indoor Air Quality Testing</a></li>
                        <li><a href="../services/maintenance-and-repair/index.html">Maintenance and Repair</a></li>
                        <li><a href="../services/hvac-design-and-installation/index.html">HVAC Design and Installation</a></li>
                        <li><a href="../services/energy-efficiency-2/index.html">Energy Efficiency</a></li>
                        <li><a href="../services/heating-and-water-2/index.html">Heating and Water</a></li>
                        <li><a href="../services/cleaning-optimization-2/index.html">Cleaning &#038; Optimization</a></li>
                            
                    </ul>
        </div>
        <!--End single sidebar-->
		
        </div><div id="bunch_brochures-3" class="side-bar widget sidebar_widget widget_bunch_brochures">      		
            <!--Start single sidebar-->
            <div class="single-sidebar">
                <ul class="brochures-dwn-link">
                    <li>
                        <a href="#">
                            <div class="icon-holder">
                                <span class="flaticon-pdf-file-format-symbol"></span>    
                            </div>
                            <div class="title-holder">
                                <h5>Services Guide.PDF</h5>    
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <div class="icon-holder">
                                <span class="flaticon-microsoft-word-document-file"></span>    
                            </div>
                            <div class="title-holder">
                                <h5>About Company.DOC</h5>    
                            </div>
                        </a>
                    </li>
                </ul> 
            </div>
            <!--End single sidebar-->
            
		</div><div id="bunch_testimonials_sidebar-3" class="side-bar widget sidebar_widget widget_bunch_testimonials_sidebar">        
        <!--Start single sidebar-->
        <div class="single-sidebar">
                    
           	<!-- Title -->
                        
            <div class="sidebar-testimonial">
                <div class="text-box">
                    <p>Cooltek helped me out when I was in a pinch. Ryan was very personable, knowledgeable, and professional. He was able to solve the problem in ...</p>
                </div>
                <div class="client-info">
                    <div class="img-box">
                        <img width="100" height="100"   alt="" data-srcset="https://727512.smushcdn.com/1872962/wp-content/uploads/2019/09/testi_profile-3.png?lossy=1&amp;strip=1&amp;webp=1 100w, https://727512.smushcdn.com/1872962/wp-content/uploads/2019/09/testi_profile-3-80x80.png?lossy=1&amp;strip=1&amp;webp=1 80w, https://727512.smushcdn.com/1872962/wp-content/uploads/2019/09/testi_profile-3-90x90.png?lossy=1&amp;strip=1&amp;webp=1 90w"  data-src="https://727512.smushcdn.com/1872962/wp-content/uploads/2019/09/testi_profile-3.png?lossy=1&strip=1&webp=1" data-sizes="(max-width: 100px) 100vw, 100px" class="attachment-aircol_75x75 size-aircol_75x75 wp-post-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="100" height="100" src="../../../../727512.smushcdn.com/1872962/wp-content/uploads/2019/09/testi_profile-341d1.png?lossy=1&amp;strip=1&amp;webp=1" class="attachment-aircol_75x75 size-aircol_75x75 wp-post-image" alt="" srcset="https://727512.smushcdn.com/1872962/wp-content/uploads/2019/09/testi_profile-3.png?lossy=1&amp;strip=1&amp;webp=1 100w, https://727512.smushcdn.com/1872962/wp-content/uploads/2019/09/testi_profile-3-80x80.png?lossy=1&amp;strip=1&amp;webp=1 80w, https://727512.smushcdn.com/1872962/wp-content/uploads/2019/09/testi_profile-3-90x90.png?lossy=1&amp;strip=1&amp;webp=1 90w" sizes="(max-width: 100px) 100vw, 100px" /></noscript>                    </div>
                    <div class="title-box">
                        <h4>Osborne Norton - <span>Bronx, New York.</span></h4>
                        <div class="review-box">
                            <ul>
                                <li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li><li><i class="fa fa-star-o"></i></li>                            </ul>
                        </div>
                    </div>
                </div>
            </div>  
            
                            
            
        </div>
		
        </div></div></div></div><div class="kc-elm kc-css-988052 kc_col-sm-9 kc_column kc_col-sm-9"><div class="kc-col-container"><div class="service-single-content">
    <!--Start top content -->
    <div class="row top-content">
        <div class="col-md-5 col-sm-12 col-xs-12">
            <div class="img-holder wow zoomInStable animated">
                <img  alt="Awesome Image" data-src="https://727512.smushcdn.com/1872962/wp-content/uploads/2017/07/ac-installation.jpg?lossy=1&strip=1&webp=1" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="><noscript><img src="../../../../727512.smushcdn.com/1872962/wp-content/uploads/2017/07/ac-installation41d1.jpg?lossy=1&amp;strip=1&amp;webp=1" alt="Awesome Image"></noscript>
            </div>
        </div>
        <div class="col-md-7 col-sm-12 col-xs-12">
            <div class="text-holder">
                <div class="title">
                    <h2>A/C Installation</h2>
                </div>
                <div class="text">
                    <span>WE ARE PROFESSIONAL. RELIABLE AND AFFORTABLE</span>
                    <p class="top">There anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious except to obtain some advantage.</p>
<p>Who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a annoying consequences resultant pleasure.</p>                </div>
            </div>
        </div>
    </div>
    <!--End top content -->
    <div class="row">
        <div class="col-md-12">
            <div class="border"></div>
        </div>
    </div>
    
        <!--Start middle content-->
    <div class="row middle-content">
        <div class="col-md-7">
            <div class="text-holder">
                <div class="title">
                    <h2>Load Calculation</h2>
                </div>
                <div class="text">
                    <p>Don't spend time and money on beautiful landscaping if you have not taken water and irrigation issues into account first. Installing a sprinkler system, leveling the ground.</p>
                    <ul>
                        						                            <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Insulation: windows, roof and walls
</li>
                                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Windows: Amount and size
</li>
                                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Roofing: Type and condition
</li>
                                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Ductwork: Layout and efficiency</li>
                                            </ul>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="video-holder">
                <img  alt="Awesome Image" data-src="https://727512.smushcdn.com/1872962/wp-content/uploads/2017/07/video-gallery.jpg?lossy=1&strip=1&webp=1" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="><noscript><img src="../../../../727512.smushcdn.com/1872962/wp-content/uploads/2017/07/video-gallery41d1.jpg?lossy=1&amp;strip=1&amp;webp=1" alt="Awesome Image"></noscript>
                <div class="overlay-gallery">
                    <div class="icon-holder">
                        <div class="icon">
                            <a class="html5lightbox" href="https://www.youtube.com/watch?v=LqTULo_YmbM">
                                <img  alt="Awesome Image" data-src="https://727512.smushcdn.com/1872962/wp-content/themes/aircol/images/icon/play-btn.png?lossy=1&strip=1&webp=1" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="><noscript><img src="../../../../727512.smushcdn.com/1872962/wp-content/themes/aircol/images/icon/play-btn41d1.png?lossy=1&amp;strip=1&amp;webp=1" alt="Awesome Image"></noscript>
                            </a>   
                        </div>
                    </div>    
                </div>
            </div>
        </div>
    </div>
    <!--End middle content-->
        
        <!--Start bottom content-->
    <div class="row bottom-content">
        <div class="col-md-12">
            <div class="accordion-box">
                 
                <!--Start single accordion box-->
                <div class="accordion accordion-block">
                    <div class="accord-btn active"><h4>Locating Indoor and Outdoor Unit</h4></div>
                    <div class="accord-content collapsed">
                        <p>The master-builder of human happiness one rejects, dislikes avoid pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure packages and web page editors now use uncover this mistaken idea and I will give you a complete of the truth, the master-builder of human happiness.</p>
                    </div>
                </div>
                <!--End single accordion box-->
                 
                <!--Start single accordion box-->
                <div class="accordion accordion-block">
                    <div class="accord-btn "><h4>Bending Copper &amp; Water Drain Pipe</h4></div>
                    <div class="accord-content ">
                        <p>The master-builder of human happiness one rejects, dislikes avoid pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure packages and web page editors now use uncover this mistaken idea and I will give you a complete of the truth, the master-builder of human happiness.</p>
                    </div>
                </div>
                <!--End single accordion box-->
                 
                <!--Start single accordion box-->
                <div class="accordion accordion-block">
                    <div class="accord-btn "><h4>Pipe Connection</h4></div>
                    <div class="accord-content ">
                        <p>The master-builder of human happiness one rejects, dislikes avoid pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure packages and web page editors now use uncover this mistaken idea and I will give you a complete of the truth, the master-builder of human happiness.</p>
                    </div>
                </div>
                <!--End single accordion box-->
                            </div>    
        </div>
    </div>
    <!--End bottom content-->
        
        <!--Start Consultation form-->
    <div class="appoinment-form">
        <div class="title">
            <h2>Make An Appoinment</h2>
        </div>
        <div role="form" class="wpcf7" id="wpcf7-f199-p183-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="http://commonsupport.net/newwp/cooltek/ac-installation/#wpcf7-f199-p183-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="199" />
<input type="hidden" name="_wpcf7_version" value="5.1.4" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f199-p183-o1" />
<input type="hidden" name="_wpcf7_container_post" value="183" />
</div>
<div class="row">
<div class="col-md-6"><span class="wpcf7-form-control-wrap text-417"><input type="text" name="text-417" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name*" /></span><span class="wpcf7-form-control-wrap email-161"><input type="email" name="email-161" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Your Mail*" /></span><span class="wpcf7-form-control-wrap text-418"><input type="text" name="text-418" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Phone Number" /></span></div>
<div class="col-md-6">
<span class="wpcf7-form-control-wrap menu-500"><select name="menu-500" class="wpcf7-form-control wpcf7-select selectmenu" aria-invalid="false"><option value="Select Service">Select Service</option><option value="A/C Installation">A/C Installation</option><option value="Maintenance &amp; Repair">Maintenance &amp; Repair</option><option value="Diagnostics">Diagnostics</option><option value="Cleaning &amp; Optimization">Cleaning &amp; Optimization</option><option value="Heating and Water">Heating and Water</option><option value="Energy Efficiency">Energy Efficiency</option></select></span><span class="wpcf7-form-control-wrap textarea-249"><textarea name="textarea-249" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Your Message.."></textarea></span></div>
</div>
<div class="row">
<div class="col-md-12"><input type="submit" value="Submit Now" class="wpcf7-form-control wpcf7-submit thm-btn bg-1" /></div>
</div>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div>    </div>
    <!--End Consultation form-->
    </div></div></div></div></div></section>
    <div class="clearfix"></div>
    <?php include 'footer.php';?>