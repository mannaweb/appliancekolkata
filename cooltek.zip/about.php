<?php include 'header.php';?>
<!--Start breadcrumb area-->     
<section class="breadcrumb-area">
	<div class="container text-center">
		<h1>About Us</h1>
	</div>
</section>
<!--End breadcrumb area-->

<!--Start breadcrumb bottom area-->
<section class="breadcrumb-botton-area">
    <div class="container">
        <div class="left">
            <ul class=""><li><a href="index.php">Home</a></li><li>About Us</li></ul>    
        </div>
    </div>
</section>
<!--End breadcrumb bottom area-->



<section class="about-us-area">

    <div class="container">

        <div class="sec-title">

            <h1><span>About Us</span></h1>

        </div>

        <div class="row">

            <div class="col-md-4">

                <div class="img-holder">

                    <img  alt="Awesome Image" data-src="https://727512.smushcdn.com/1872962/wp-content/uploads/2017/07/about-us.jpg?lossy=1&strip=1&webp=1" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="><noscript><img src="../../../../727512.smushcdn.com/1872962/wp-content/uploads/2017/07/about-us41d1.jpg?lossy=1&amp;strip=1&amp;webp=1" alt="Awesome Image"></noscript>

                </div>    

            </div>

            <div class="col-md-4">

                <div class="middle-text-box">

                    <div class="single-item top">

                        <h3>Who We Are</h3>

                        <p>Cooltek was established in 1990 by John Britto and Zat Maxwell in Newyork, United States. John and Zat continue to manage the company today and take pride in providing a family environment for all of our employees. Are very hands-on in all aspects</p>

                    </div> 

                    <div class="single-item">

                        <h3>What We Do</h3>

                        <p>Our company provides a full spectrum of work of any level of complexity. Our team consists of highly qualified professionals, who have been in the industry for no less than 6 years. We have gained extensive experience while solving the most complex technical.</p>

                    </div>     

                </div>

            </div>

            <div class="col-md-4">

                <div class="right-info-box">

                    <div class="top">

                        <div class="iocn-holder">

                            <span class="flaticon-24-hours-3"></span>

                        </div>

                        <div class="text-holder">

                            <h3>24/7 Customer Care</h3>
<span>For Emergency Service</span> 

                        </div>

                    </div>

                    <div class="middle">

                        <h1>1800-456-789</h1>

                        <p>We can provide expert 24 hour Emergency
Service, Contact when you need it!.</p>    

                    </div>

                    <div class="bottom">

                        <h4>For queries:</h4>

                        <ul>

                            <li><span>Tel:</span> (+321)-123-45-678</li>

                            <li><span>Email:</span> Mailus@example.com </li>

                        </ul>

                    </div>

                </div>

            </div>

        </div>
	
    </div>

</section>
<?php include 'footer.php';?>
<!--End about us area-->
